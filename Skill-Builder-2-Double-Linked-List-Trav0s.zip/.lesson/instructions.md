## Lesson  
1.  Watch video:  [Introduction to Linked Lists](https://youtu.be/LOHBGyK3Hbs)
2.  Watch Video: [Programming a Linked List](https://youtu.be/3YqNN78xVJM)

## Introduction 
In this assignment, we will be building for ourselves a data structure known as a double-linked list.  A double linked list appears very similar to an ArrayList, but internally they are quite different.

In a linked list, data is held in an object commonly refered to as a Node. Nodes are connected using links, which are simply object variables that point to an object of type Node. In a single-linked list, each Node has one link that point to the next Node, thus forming a chain. The last Node's link is null, indicating that there are no further nodes.  In a double linked list, each node has two links: one that points to the previous node (null if it is the first), and one that points to the next node (null if it is the last).

## Assignment
Your assignment is to create a public class LinkedList which will maintain a double linked list of nodes that contain a String. 

Use the given Node class, which simply provides an object that has a reference the the previous and next Node, as well as a variable to hold a String value. <br> <br>
Note that these variables are protected. This allows you to refer to them directly within your LinkedList class, but it also does not allow the client (which would be outside of your package) to modify these values. Thus, your LinkedList completely controls these values. In fact, you would normally make this an inner class (as there is no reason for your client to even see this class), but for unit test purposes, you will simply add it to your project. 

Your LinkedList class will then internally store a list of Node objects, and provide the following methods which act upon that list:
```java
public void add(String element) //Inserts the specified element at the end of the list.

public void add(int index, String element) //Inserts the specified element at the specified position in the list; If the index is "out of bounds", an 'OutOfBounds' exception should be thrown.

public String toString() //Return a text representation of the linked list in the form [element1, element2, element2

public int size() //Returns the number of elements in this list

public void clear() //Removes all of the elements from the list

public String get(int index) //Returns the element at the specified position in the list. Return empty string if the index is "out of bounds".

public void set(int index, String element) //Sets the element at the specified position in the list to the given value. If the index is "out of bounds", no action is required.

public void remove(int index) //Removes the element at the specified position in the list. If the index is "out of bounds", no action is required.
```
## Hint:
The first method you will want to implement is the add(String element) and the add(int index, String element) methods. Immediately after that, you will want to implement the toString() method. This overrides the default representation of the object, and will allow you to visualize what elements are currently in your Linked List.
