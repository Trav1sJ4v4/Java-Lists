class Main {
  public static void main(String[] args) {
    LinkedList myList = new LinkedList();
    myList.add("red");
    myList.add("Green");
    myList.add("yellow");
    myList.add("Blue");
    // Displaying the list
    System.out.println("Linked List: " + myList.toString());
    System.out.println("Size of the list: " + myList.size());

    // Adding elements at specific positions
    myList.add(1, "Orange");
    System.out.println("Linked List after adding 'Orange' at index 1: " + myList.toString());

    // Getting and setting elements
    System.out.println("Element at index 2: " + myList.get(2));
    myList.set(2, "Lime Green");
    System.out.println("Linked List after setting 'Lime Green' at index 2: " + myList.toString());

    // Removing elements
    myList.remove(0);
    System.out.println("Linked List after removing element at index 0: " + myList.toString());

    // Clearing the list
    myList.clear();
    System.out.println("Linked List after clearing: " + myList.toString());
    System.out.println("Size of the list after clearing: " + myList.size());
  }
}
class Node{
  protected Node prev;
  protected Node next;
  protected String data;

  public Node(String data){
    this.data = data;
    this.prev = null;
    this.next = null;
  }  
}
 class LinkedList{
  private Node first;
  private Node last;
  private int size;
  //construct
  public LinkedList(){
    this.first = null;
    this.last = null;
    this.size = 0;
  }



  //add element
    public void add(String element){
      Node temp = new Node(element);
      if(first == null){
        first = temp;
        last= temp;
      }
      else{
        last.next = temp;
        temp.prev = last;
        last = temp;
      }
      size++;
    }
      
    //Inserts the specified element at the specified position in the list; If the index is "out of bounds", an 'OutOfBounds' exception should be thrown.
    public void add(int index, String element){
      if(index <0 || index > size){
        throw new IndexOutOfBoundsException("Thats not there...");
        
      }
      if(index == size){
        add(element);
        return;
      }
      Node newNode = new Node(element);
      if(index == 0){
          newNode.next = first;
        first.prev = newNode;
        first = newNode;
      }
      else{
        Node current = getNodeAtIndex(index - 1);
        Node temp = current.next;
        newNode.prev = current;
        newNode.next = temp;
        current.next = newNode;
        temp.prev =newNode;
      }
      size ++;
     
    } 

    public String toString(){
      StringBuilder result = new StringBuilder("[");
      Node current = first;
      while (current != null){
        result.append(current.data);
        if(current.next != null){
          result.append(", ");
        }
        current = current.next;
      }
      result.append("]");
      return result.toString();
    } 

    public int size(){
      return size;
    }

    public void clear(){
      first = null;
      last = null;
      size = 0;
    }

    public String get(int index){
      if(index < 0 || index >= size){
        return "";
      }
      Node current = getNodeAtIndex(index);
      return current.data;
    }

    public void set(int index, String element){
      if(index < 0 || index >= size){
        return;
      }
        Node current = getNodeAtIndex(index);
      current.data = element;
    }

    public void remove(int index) {
      if(index < 0 || index >= size){
        return;
      }
      if(index == 0){
        first = first.next;
        if(first != null){
          first.prev = null;
        }
        else{
          Node current = getNodeAtIndex(index);
          Node prevNode = current.prev;
          Node nextNode = current.next;
          prevNode.next = nextNode;
          if (nextNode != null) {
            nextNode.prev = prevNode;
          } else {
            last = prevNode;
          }
        }
        size--;
      }
    }
  private Node getNodeAtIndex (int index){
    Node current = first;
    for(int i =0; i< index; i++){
      current = current.next;
    }
    return current;
  }

 }